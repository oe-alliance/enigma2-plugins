#!/bin/sh
# Name: gst-neon-libs_0.26.tar.gz
# Version: 0.1.0
# Type: plugin

rm -rf /usr/lib/gstreamer-0.10/libgstneonhttpsrc.so
rm -rf /usr/lib/libneon.so
rm -rf /usr/lib/libneon.so.26
rm -rf /usr/lib/libneon.so.26.0.4
rm -rf /usr/uninstall/gst-neon-libs_0.26_delfile.sh

exit 0

######################################
####### Powered by Gemini Team #######
## http://www.i-have-a-dreambox.com ##
######################################
